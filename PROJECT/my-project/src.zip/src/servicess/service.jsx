import { Link } from "react-router-dom";
import { FooterDemo } from "../Footer/footer";
import { NavBar } from "../navbar/navbar";

export function ServicesDemo() {
  return (
    <div className="container-fluid">
      <NavBar />
      
      
    </div>
  );
}
