export function Servicemenu() {
  return (
    <div className="container">
      <div className="row bg-black text-white">
        <div className="col-4">sjijs</div>
        <div className="col-4">sksn</div>
        <div className="col-4">skmksm</div>
      </div>
    </div>
  );
}
